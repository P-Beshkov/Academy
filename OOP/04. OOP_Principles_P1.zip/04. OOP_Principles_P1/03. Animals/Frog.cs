public class Frog : Animal
{
    public Frog(string name, bool isFemale, int age) : base(name, isFemale, age)
    {
    }
}