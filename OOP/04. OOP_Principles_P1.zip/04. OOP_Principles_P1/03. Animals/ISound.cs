﻿interface ISound
{    
    void ProduceSound();
}