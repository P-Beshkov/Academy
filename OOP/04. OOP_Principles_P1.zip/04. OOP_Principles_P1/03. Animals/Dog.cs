public class Dog : Animal
{
    public Dog(string name, bool isFemale, int age) : base(name, isFemale, age)
    {
    }
}