﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcademyPopcorn
{
    public class EngineMod : Engine
    {
        public void ShootPlayerRacket()
        {

        }
        public EngineMod(IRenderer renderer, IUserInterface userInterface) : base(renderer,userInterface)
        {

        }
    }
}
